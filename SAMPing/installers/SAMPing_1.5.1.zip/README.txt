This version of SAMPing must be ran from C:\SAMPing. 

I don't know why I coded that in, I'm sorry.

https://laim.scot/samping